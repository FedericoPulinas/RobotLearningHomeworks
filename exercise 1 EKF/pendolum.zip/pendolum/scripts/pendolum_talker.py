#!/usr/bin/env python

import rospy
import numpy as np
from scipy.integrate import odeint
from rospy_tutorials.msg import Floats

#global variables
deltaTime=0.05
x0 = np.array([np.pi/3, 0.5])


def stateSpaceModel(x,t):
    g=9.81
    l=1
    dxdt=np.array([x[1], -(g/l)*np.sin(x[0])])
    return dxdt

def talker():
    pendolum = rospy.Publisher('pendolum_true_state', Floats, latch=True, queue_size=100)
    rospy.init_node('pendolum_talker', anonymous=False)
    rate = rospy.Rate(1/deltaTime) # 10hz
    prev_Time = 0 - deltaTime
    curr_Time = 0
    x_t_true = x0
    
    while not rospy.is_shutdown():
        curr_Time = prev_Time + deltaTime
        #write all the operation that should be performed while running
        x_t_true = odeint(stateSpaceModel, x_t_true, [prev_Time, curr_Time])
        prev_Time = curr_Time
        #print("array", np.shape(x_t_true[i]))
        x_t_true = x_t_true[-1]
        rospy.loginfo(x_t_true)
        pendolum.publish(x_t_true)

        rate.sleep()

if __name__ == '__main__':
    try:
        print("pendolum_talker")
        talker()
    except rospy.ROSInterruptException:
        pass
