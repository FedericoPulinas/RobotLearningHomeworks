#!/usr/bin/env python


import rospy
import numpy as np
from scipy.integrate import odeint
from rospy_tutorials.msg import Floats


class ExtendedKalmanFilter(object):

    def __init__(self, x0, P0, Q, R):
        self.x0 = x0
        self.P0 = P0
        self.Q = Q
        self.R = R
        self.dT = 0.05

        self.g = 9.81
        self.l = 1

        self.currentTimeStep = 0

        self.priorMeans = []
        self.priorMeans.append(None)  # no prediction step for timestep=0
        self.posteriorMeans = []
        self.posteriorMeans.append(x0)

        self.priorCovariances=[]
        self.priorCovariances.append(None)  # no prediction step for timestep=0
        self.posteriorCovariances=[]
        self.posteriorCovariances.append(P0)


    def stateSpaceModel(self, x, t):
        dxdt = np.array([[x[1,0]], [-(self.g/self.l)*np.sin(x[0,0])]])

        return dxdt
    
    def discreteTimeDynamics(self, x_t):
        x_tp1 = x_t + self.dT*self.stateSpaceModel(x_t, None)
        return x_tp1

    def jacobianStateEquation(self, x_t):
        A = np.zeros(shape=(2,2))  # TODO: shape?
        A = np.array([ [1, self.dT],
                         [-1 * self.dT * (self.g/self.l) * np.cos(x_t[1,0]), 1]] )
        return A

    def jacobianMeasurementEquation(self, x_t):
        C = np.zeros(shape=(1,2))
        C = np.array([[1, 0]])
        return C
    
    def forwardDynamics(self):
        self.currentTimeStep = self.currentTimeStep+1  # t-1 ---> t
        
        x_t_prior_mean = self.discreteTimeDynamics(self.posteriorMeans[self.currentTimeStep - 1])

        A_t_minus = self.jacobianStateEquation(self.posteriorMeans[self.currentTimeStep - 1])

        x_t_prior_cov = A_t_minus @ self.posteriorCovariances[self.currentTimeStep - 1] @ A_t_minus.T + self.Q

        self.priorMeans.append(x_t_prior_mean)
        self.priorCovariances.append(x_t_prior_cov)

    def updateEstimate(self, z_t):
        Ct = self.jacobianMeasurementEquation(self.priorMeans[self.currentTimeStep])
        K_t = self.priorCovariances[self.currentTimeStep] @ Ct.T @ np.linalg.inv(Ct @ self.priorCovariances[self.currentTimeStep] @ Ct.T + self.R)
        x_t_mean = self.priorMeans[self.currentTimeStep] + K_t @ (z_t - Ct @ self.priorMeans[self.currentTimeStep])
        x_t_cov = (np.eye(2, 2) - K_t @ Ct) @ self.priorCovariances[self.currentTimeStep]
        self.posteriorMeans.append(x_t_mean)
        self.posteriorCovariances.append(x_t_cov)


def callback(data, EKF):
    EKF.forwardDynamics()

    EKF.updateEstimate(data.data[0])
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)

    rospy.loginfo('efk estimate %d %d', EKF.posteriorMeans[-1][0], EKF.posteriorMeans[-1][1])
    ekf_publisher.publish(EKF.posteriorMeans[-1])
    


def listener():
    rospy.init_node('ekf_lt', anonymous=False)
    x0 = np.array([np.pi/3, 0.5])
    x_0_mean = np.zeros(shape=(2,1))  # column-vector
    x_0_mean[0] = x0[0] + 3*np.random.randn()
    x_0_mean[1] = x0[1] + 3*np.random.randn()
    x_0_cov = 10*np.eye(2,2)  # initial value of the covariance matrix

    Q=0.00001*np.eye(2,2)
    R=0.05

    EKF = ExtendedKalmanFilter(x_0_mean, x_0_cov, Q, R)

    ekf_sub = rospy.Subscriber('sensor_noisy_states', Floats, callback, EKF)
    rospy.spin()

if __name__ == '__main__':
    try:
        ekf_publisher = rospy.Publisher('ekf_predictions', Floats, latch=True, queue_size=100)
        listener()
    except rospy.ROSInterruptException:
        pass
