#!/usr/bin/env python

import rospy
import numpy as np
from scipy.integrate import odeint
from rospy_tutorials.msg import Floats

deltaTime=0.05
simulationSteps= 1000
totalSimulationTimeVector=np.arange(0, simulationSteps*deltaTime, deltaTime)

measurement_noise_var = 0.01

def callback(data):
    global measurement_noise_var
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)
    rate = rospy.Rate(1/deltaTime) # 10hz
    #ospy.loginfo("processing measured datas ... %f %f", data.data[0], data.data[1])
    
    z_t = data.data + np.sqrt(measurement_noise_var)*np.random.randn()
    
    rospy.loginfo(z_t)
    sensor_publisher.publish(z_t)
    #print(z_t)



def listener():

    rospy.init_node('sensor_lt', anonymous=False)
    sensor = rospy.Subscriber('pendolum_true_state', Floats, callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        
        sensor_publisher = rospy.Publisher('sensor_noisy_states', Floats, latch=True, queue_size=100)
        listener()
    except rospy.ROSInterruptException:
        pass
